import { spawnSync } from 'node:child_process';
import { homedir } from 'node:os';
import { isAbsolute, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 12)) {
  console.error('请使用 Node.js 22.12 或更高版本。');
  process.exit(1);
}

const args = process.argv.slice(2);
const mode = args[0];
const app = fileURLToPath(new URL('../assets/app/', import.meta.url));
const port = process.env.LOCAL_BOARD_PORT ?? '4390';
const dataDir = process.env.LOCAL_BOARD_DATA_DIR ?? join(homedir(), '.local-project-board');
if (!/^[1-9]\d{0,4}$/.test(port) || Number(port) > 65535 || !isAbsolute(dataDir)) {
  console.error('LOCAL_BOARD_PORT 须为 1 至 65535，LOCAL_BOARD_DATA_DIR 须为绝对路径。');
  process.exit(1);
}

const url = 'http://127.0.0.1:' + port;
if (mode === 'location') {
  console.log(JSON.stringify({ url, dataDir }, null, 2));
  process.exit(0);
}

const start = mode === 'start';
if (start && args.length !== 1) {
  console.error('用法为 node scripts/local-board.mjs start');
  process.exit(1);
}

const child = spawnSync(process.execPath, start ? [join(app, 'server.mjs')] : [join(app, 'board.mjs'), ...args], {
  stdio: 'inherit',
  env: { ...process.env, BOARD_PORT:port, BOARD_DATA_DIR:dataDir },
});
if (child.error) console.error(child.error.message);
process.exitCode = child.status ?? (child.signal === 'SIGINT' ? 130 : 1);
