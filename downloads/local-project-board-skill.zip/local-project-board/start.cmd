@echo off
node "%~dp0scripts\local-board.mjs" start
if errorlevel 1 pause
