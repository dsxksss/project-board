export default {
  projects: ['项目 A', '项目 B', '私有化部署'],
  products: ['Web', '服务端', '客户端'],
  STAGES: ['待核对', '待推进', '进行中', '待发布', '待部署', '待验收', '已完成'],
};
